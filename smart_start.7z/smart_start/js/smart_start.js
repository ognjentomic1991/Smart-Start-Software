$.ajaxSetup({ cache: false });
window.viki = window.viki || {};

viki.innit = function(){
	alert("This will fuck everything up, Just click OK!");
}

function get_mobile_operating_system(){
	var userAgent = navigator.userAgent || navigator.vendor || window.opera;
	if (/windows phone/i.test(userAgent)){ return "Windows Phone"; }
	if (/android/i.test(userAgent)){ return "Android"; }
	if (/iPad|iPhone|iPod/.test(userAgent) && !window.MSStream){ return "iOS"; }
	return "desktop_laptop";
}

$(document).ready(function(){
	setTimeout(function(){
		// viki.innit();
	}, 3000);
});