<?php
	if(!isset($_GET['load_file'])){$_GET['load_file'] = "SP2_OsnovniPodaci.csv";}
	if(!isset($_GET['sort_by'])){$_GET['sort_by'] = "﻿MaticniBroj";}

	$file = $_GET['load_file']."";
	$csv = array_map('str_getcsv', file($file));

	$table_label = array();
	for($i = 0; $i < sizeof($csv[0]); $i++){
		array_push($table_label, $csv[0][$i]);
	}

	array_walk($csv, function(&$a) use ($csv){
		$a = array_combine($csv[0], $a);
	});
	array_shift($csv);

	usort($csv, function($a, $b) {
	    return $a[$_GET['sort_by']] <=> $b[$_GET['sort_by']];
	});

	function gen_menu($csv, $i, $trgt){
		if(isset($csv[$i][$trgt])){
			${"unique_".$trgt} = array(); 
			echo "<ul>";
			for($i = 0; $i < sizeof($csv); $i++) {
				if(!in_array($csv[$i][$trgt], ${"unique_".$trgt})){
					array_push(${"unique_".$trgt}, $csv[$i][$trgt]);
					echo "".
						"<li>".
							"<div>".$csv[$i][$trgt]."</div>".
						"</li>";
				}
			}
			echo "</ul>";
		}
	}

	function menu_load_file($handle){
		if ($handle = opendir('.')){
			while (false !== ($entry = readdir($handle))){
				if ($entry != "." && $entry != ".." && $entry != "import.xlsx" && $entry != "index.php" && $entry != "obsolete" ){?>
					<li><a href="<?php echo $_SERVER['PHP_SELF'];?>?load_file=<?php echo $entry;?>&sort_by=﻿MaticniBroj"><?php echo substr($entry, 0, -4);?></a></li>
				<?php }
			}
			closedir($handle);
		}
	}
?>
<!DOCTYPE html>
<html>
	<head>
		<style>
			:root {
				--nav_height: 12em;
				--table_header_height: 2em;
			}
			body { margin: 0; padding: 0; font-family: Calibri, sans; font-size: 0.8em; filter: invert(1); }
			nav { position: fixed; top: 0px; left: 0px; margin: 0; padding: 0; width: 100vw; background: rgba(0,0,0,0.25); box-shadow: 0px 0px 5px 0px #000; overflow: hidden; }
			nav ul { margin: 0; padding: 0; list-style: none; }
			.list_company_wrapper { margin: 0; padding: 0; height: calc(100vh - var(--nav_height));  overflow-y: scroll; scroll-behavior: smooth;  }
			.list_company { position: relative; margin: 0; padding: 0; width: 100%; list-style: none; display: table; }
			.list_company li { width: auto; display: table-row; cursor: pointer; background: rgba(200,200,200); }
			.list_company li:nth-child(1) { position: fixed; top: 0px; color: #eee; background: rgba(50,50,50,1); }
			.list_company li:nth-child(1):hover { filter: unset; }
			.list_company li:nth-child(even) { background: rgba(230,230,230); }
			.list_company li:hover { filter: invert(1); }
			.list_company li div { padding: 0.5em; display: table-cell; }
			nav { overflow: hidden; }
			nav ul { float: left; overflow: hidden; }
			nav .load_file li a { padding: 0.5em 1em; display: block; color: #333; background: #ddd; text-decoration: none; }
			nav .load_file li a:hover { filter: invert(1); }
			.loading { position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; text-align: center; background: rgba(0,0,0,0.95); }
			.loading p { color: #eee; font-size: 42px; margin-top: calc(50vh - 84px); }
		</style>
		<script type="text/javascript" src="../js/jquery.min.js"></script>

		<script type="text/javascript">
			$( document ).ready(function(){
				$(".loading").fadeOut(150);
				$("nav .load_file li a").on("click", function(e){
					$(".loading").fadeIn(150, function(){
					});
				});
				$("body").css({ "padding-top": $("nav").height()+"px" });
				$(".list_company").css({ "padding-top": $(".list_company li:nth-child(1)").height()+"px" });
				$(".list_company li:nth-child(1)").css({ "top" : $("nav").height()+"px" });

				var label_count = 1;
				$(".list_company li:nth-child(1) div").each(function(){
					$(this).width($(".list_company li:nth-child(2) div:nth-child("+label_count+")").width());
					label_count++;
				});
				$(".list_company li:nth-child(2)").height(1);

			});
		</script>
		
	</head>
	<body>
		<nav>
			<ul class="load_file">
				<?php
					menu_load_file("/");
				?>
			</ul>
				<?php
					gen_menu($csv, $i, "Status");
					gen_menu($csv, $i, "MaticniBroj");
				?>
		</nav>
		<div class="list_company_wrapper">
			<ul class="list_company">
				<?php
					echo "<li>";
						for($y = 0; $y < sizeof($table_label); $y++){
							echo "<div>".$table_label[$y]."</div>";
						}
					echo "</li>";
					echo "<li>";
						for($y = 0; $y < sizeof($table_label); $y++){
							echo "<div>".$table_label[$y]."</div>";
						}
					echo "</li>";
					for($i = 0; $i < sizeof($csv); $i++) {
						if($csv[$i][$table_label[0]] != ""){
							echo "<li>";
								// "<div>".$i."</div>";
								for($x = 0; $x < sizeof($table_label); $x++){
									echo "<div>".$csv[$i][$table_label[$x]]."</div>";
								}
							echo "</li>";
						}
					}
				?>
			</ul>
		</div>
		<div class="loading"><p>...working...</p></div>
	</body>
</html>
